# AgentX — Autonomous Multi-Agent AI

AgentX is a multi-agent AI project. Its intended workflow is:

**User → Planner → Supervisor → Researcher / Data Analyst → Fact Checker → Report Writer → Final Response**

> **Repository preparation status:** This package contains the cleaned GitHub metadata/configuration files supplied so far. The application source code (`backend/` and `frontend/`) was not included in the uploaded files, so this is not yet a runnable application or a deployable GitHub Pages website.

## Before publishing

- Keep `.env` private. Never commit API keys, passwords, tokens, or production secrets.
- Do not commit local database files such as `agentx.db`.
- Copy `.env.example` to `.env` for local development and fill in your own credentials.
- If a real key was previously exposed, revoke/rotate it with its provider before using it again.

## Project files still needed

Add the actual application files before publishing, for example:

```text
AgentX/
├── backend/
│   ├── app/
│   └── requirements.txt
├── frontend/
│   └── index.html
├── .env.example
├── .gitignore
└── README.md
```

Only include folders and files that exist in your actual project. Do not create empty placeholder source files and present them as working code.

## GitHub Pages deployment

GitHub Pages hosts static files (HTML, CSS, JavaScript). It cannot run the Python FastAPI backend. Once the real frontend is added, publish the static frontend from the repository's `frontend/` directory (or move the static site files to the configured Pages publishing directory). Deploy the FastAPI backend separately on a Python-capable hosting service, then configure the frontend to call that backend URL.

## Run locally

The original project notes describe these commands, once the missing backend files are restored:

```bash
python -m venv .venv
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r backend/requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --app-dir backend --port 8080
```

Open `http://127.0.0.1:8080/docs` for the FastAPI Swagger UI, if the backend source is present.
